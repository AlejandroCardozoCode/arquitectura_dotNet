﻿using System;
using System.Collections.Generic;

namespace Api.Models
{
    public partial class Productost1
    {
        public int Idproducto { get; set; }
        public string? Nombre { get; set; }
        public int? Precio { get; set; }
        public int? Unidades { get; set; }
        public string? Presentacion { get; set; }
    }
}
