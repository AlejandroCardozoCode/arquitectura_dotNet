public class Peticion
{
    public int id { get; set; }
    public int cantidad { get; set; }
}
