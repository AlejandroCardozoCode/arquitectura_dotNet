import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;

import controladorServicios.ControladorServicios;

public class Main {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		ControladorServicios controlador = new ControladorServicios();
		//boolean respuesta = controlador.comprobarInformacionFinanciera(100812, "4539217197594262", "06/2024", 1);
		boolean respuesta = controlador.realizarCobro(127084, "300", 1);
		System.out.println(respuesta);
	}
}
